package com.fathur.moviecatalog.ui.detail;

import androidx.arch.core.executor.testing.InstantTaskExecutorRule;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Observer;

import com.fathur.moviecatalog.data.source.MovieRepository;
import com.fathur.moviecatalog.data.source.local.entity.MovieEntity;
import com.fathur.moviecatalog.data.source.local.entity.TvShowEntity;
import com.fathur.moviecatalog.utils.DataDummy;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class DetailMovieViewModelTest {
    @Rule
    public InstantTaskExecutorRule instantTaskExecutorRule = new InstantTaskExecutorRule();
    private DetailMovieViewModel viewModel;
    private MovieEntity dummymovie = DataDummy.generateDummyMovies().get(0);
    private TvShowEntity dummytvshow = DataDummy.generateDummyTvShow().get(0);
    private String mvid = dummymovie.getMvid();
    private String tvid = dummytvshow.getTvid();
    @Mock
    private MovieRepository movieRepository;

    @Mock
    private Observer<MovieEntity> movieObserver;
    @Mock
    private Observer<TvShowEntity> tvshowObserver;

    @Before
    public void setUp() {
        viewModel = new DetailMovieViewModel(movieRepository);
        viewModel.setSeletectedMovie(mvid);

        viewModel = new DetailMovieViewModel(movieRepository);
        viewModel.setSeletectedMovie(tvid);
    }

    @Test
    public void getMovies() {
        MutableLiveData<MovieEntity> movie = new MutableLiveData<>();
        movie.setValue(dummymovie);

        when(movieRepository.getAllMoviesById(mvid)).thenReturn(movie);
        viewModel.setSeletectedMovie(dummymovie.getMvid());
        MovieEntity movieEntity = viewModel.getMovies().getValue();
        verify(movieRepository).getAllMoviesById(mvid);
        assertNotNull(movieEntity);
        assertEquals(movieEntity.getMvid(), movieEntity.getMvid());
        assertEquals(movieEntity.getTitle(), movieEntity.getTitle());
        assertEquals(movieEntity.getDescription(), movieEntity.getDescription());
        assertEquals(movieEntity.getImagePath(), movieEntity.getImagePath());
        assertEquals(movieEntity.getWriterfilm(), movieEntity.getWriterfilm());

        viewModel.getMovies().observeForever(movieObserver);
        verify(movieObserver).onChanged(dummymovie);
    }

    @Test
    public void getTvShow() {
        MutableLiveData<TvShowEntity> tvshow = new MutableLiveData<>();
        tvshow.setValue(dummytvshow);

        when(movieRepository.getAllTVShowById(tvid)).thenReturn(tvshow);
        viewModel.setSeletectedMovie(dummytvshow.getTvid());
        TvShowEntity tvShowEntity = viewModel.getTvShow().getValue();
        verify(movieRepository).getAllTVShowById(tvid);
        assertNotNull(tvShowEntity);
        assertEquals(tvShowEntity.getTvid(), tvShowEntity.getTvid());
        assertEquals(tvShowEntity.getTitle(), tvShowEntity.getTitle());
        assertEquals(tvShowEntity.getDescription(), tvShowEntity.getDescription());
        assertEquals(tvShowEntity.getImagePath(), tvShowEntity.getImagePath());
        assertEquals(tvShowEntity.getWriteFilm(), tvShowEntity.getWriteFilm());

        viewModel.getTvShow().observeForever(tvshowObserver);
        verify(tvshowObserver).onChanged(dummytvshow);
    }

}