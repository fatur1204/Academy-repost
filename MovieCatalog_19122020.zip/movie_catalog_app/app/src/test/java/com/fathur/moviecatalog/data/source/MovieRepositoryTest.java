package com.fathur.moviecatalog.data.source;

import androidx.arch.core.executor.testing.InstantTaskExecutorRule;

import com.fathur.moviecatalog.data.source.local.entity.MovieEntity;
import com.fathur.moviecatalog.data.source.local.entity.TvShowEntity;
import com.fathur.moviecatalog.data.source.remote.RemoteDataSource;
import com.fathur.moviecatalog.data.source.remote.response.MovieResponse;
import com.fathur.moviecatalog.data.source.remote.response.TVShowResponse;
import com.fathur.moviecatalog.utils.DataDummy;
import com.fathur.moviecatalog.utils.LiveDataTestUtil;

import org.junit.Rule;
import org.junit.Test;
import org.mockito.Mockito;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.verify;

public class MovieRepositoryTest {
    @Rule
    public InstantTaskExecutorRule instantTaskExecutorRule = new InstantTaskExecutorRule();

    private RemoteDataSource remote = Mockito.mock(RemoteDataSource.class);
    private FakeMovieRepository academyRepository = new FakeMovieRepository(remote);

    private List<MovieResponse> movieresponse = DataDummy.generateRemoteDummyMovies();
    private String mvid = movieresponse.get(0).getMvid();
    private ArrayList<TVShowResponse> tvresponse = DataDummy.generateRemoteDummyTvShow();
    private String tvid = tvresponse.get(0).getMvid();

    @Test
    public void getAllMovies() {
        doAnswer(invocation -> {
            ((RemoteDataSource.LoadMoviesCallback) invocation.getArguments()[0])
                    .onAllCoursesReceived(movieresponse);
            return null;
        }).when(remote).getAllMovies(any(RemoteDataSource.LoadMoviesCallback.class));
        List<MovieEntity> movieEntities = LiveDataTestUtil.getValue(academyRepository.getAllMovies());
        verify(remote).getAllMovies(any(RemoteDataSource.LoadMoviesCallback.class));
        assertNotNull(movieEntities);
        assertEquals(movieresponse.size(), movieEntities.size());
    }

    @Test
    public void getAllTVShow() {
        doAnswer(invocation -> {
            ((RemoteDataSource.LoadTVShowCallback) invocation.getArguments()[0])
                    .onAllCoursesReceived(tvresponse);
            return null;
        }).when(remote).getAllTVShow(any(RemoteDataSource.LoadTVShowCallback.class));
        List<TvShowEntity> tvShowEntities = LiveDataTestUtil.getValue(academyRepository.getAllTVShow());
        verify(remote).getAllTVShow(any(RemoteDataSource.LoadTVShowCallback.class));
        assertNotNull(tvShowEntities);
        assertEquals(tvresponse.size(), tvShowEntities.size());
    }

}