package com.fathur.moviecatalog.data.source;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.fathur.moviecatalog.data.source.local.entity.MovieEntity;
import com.fathur.moviecatalog.data.source.local.entity.MovieWithModule;
import com.fathur.moviecatalog.data.source.local.entity.TVWithModule;
import com.fathur.moviecatalog.data.source.local.entity.TvShowEntity;
import com.fathur.moviecatalog.data.source.remote.RemoteDataSource;
import com.fathur.moviecatalog.data.source.remote.response.MovieResponse;
import com.fathur.moviecatalog.data.source.remote.response.TVShowResponse;
import com.fathur.moviecatalog.vo.Resource;

import java.util.ArrayList;
import java.util.List;

public class FakeMovieRepository implements MovieDataSource {

    private volatile static FakeMovieRepository INSTANCE = null;
    private final RemoteDataSource remoteDataSource;
    private final String TAG = FakeMovieRepository.class.getSimpleName();

    public FakeMovieRepository(@NonNull RemoteDataSource remoteDataSource) {
        this.remoteDataSource = remoteDataSource;
    }

    @Override
    public LiveData<List<MovieEntity>> getAllMovies() {
        MutableLiveData<List<MovieEntity>> movieresult = new MutableLiveData<>();
        remoteDataSource.getAllMovies(movieResponses -> {
            ArrayList<MovieEntity> movielist = new ArrayList<>();
            for (MovieResponse response : movieResponses) {
                MovieEntity movies = new MovieEntity(response.getMvid(),
                        response.getTitle(),
                        response.getDescription(),
                        response.getWriterfilm(),
                        response.getImagePath());
                movielist.add(movies);
            }
            movieresult.postValue(movielist);
        });
        return movieresult;
    }


    @Override
    public LiveData<Resource<List<MovieEntity>>> getAllMoviesById(String mvId) {
        MutableLiveData<MovieEntity> movieResult = new MutableLiveData<>();
        remoteDataSource.getAllMovies(movieResponses -> {
            MovieEntity movies = null;
            for (MovieResponse response : movieResponses) {
                if (response.getMvid().equals(mvId)) {
                    movies = new MovieEntity(response.getMvid(),
                            response.getTitle(),
                            response.getDescription(),
                            response.getWriterfilm(),
                            response.getImagePath());
                }
            }
            movieResult.postValue(movies);
        });
        return movieResult;
    }

    @Override
    public LiveData<Resource<MovieWithModule>> getModuleMovieById(String courseId) {
        MutableLiveData<List<MovieEntity>> moduleResults = new MutableLiveData<>();
        remoteDataSource.getAllMoviesId(courseId, moduleResponses -> {
            ArrayList<MovieEntity> moduleList = new ArrayList<>();
            for (MovieResponse response : moduleResponses) {
                MovieEntity course = new MovieEntity(response.getMvid(),
                        response.getTitle(),
                        response.getDescription(),
                        response.getWriterfilm(),
                        response.getImagePath());

                moduleList.add(course);
            }
            moduleResults.postValue(moduleList);
        });

        return moduleResults;
    }

    @Override
    public LiveData<List<TvShowEntity>> getAllTVShow() {
        MutableLiveData<List<TvShowEntity>> tvshowResult = new MutableLiveData<>();
        remoteDataSource.getAllTVShow(tvShowResponses -> {
            ArrayList<TvShowEntity> tvshowlist = new ArrayList<>();
            for (TVShowResponse response : tvShowResponses) {
                TvShowEntity tvshow = new TvShowEntity(response.getMvid(),
                        response.getTitle(),
                        response.getDescription(),
                        response.getVoteaverage(),
                        response.getImagePath());
                tvshowlist.add(tvshow);
            }
            tvshowResult.postValue(tvshowlist);
        });

        return tvshowResult;
    }

    @Override
    public LiveData<Resource<TVWithModule>> getAllTVShowById(String mvId) {
        MutableLiveData<TvShowEntity> tvshowResult = new MutableLiveData<>();

        remoteDataSource.getAllTVShow(tvShowResponses -> {
            TvShowEntity tvshows = null;
            for (TVShowResponse response : tvShowResponses) {
                if (response.getMvid().equals(mvId)) {
                    tvshows = new TvShowEntity(response.getMvid(),
                            response.getTitle(),
                            response.getDescription(),
                            response.getVoteaverage(),
                            response.getImagePath());
                }
            }
            tvshowResult.postValue(tvshows);
        });
        return tvshowResult;
    }

}
