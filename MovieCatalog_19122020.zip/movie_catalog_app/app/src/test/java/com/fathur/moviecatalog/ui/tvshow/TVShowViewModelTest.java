package com.fathur.moviecatalog.ui.tvshow;

import androidx.arch.core.executor.testing.InstantTaskExecutorRule;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Observer;

import com.fathur.moviecatalog.data.source.MovieRepository;
import com.fathur.moviecatalog.data.source.local.entity.TvShowEntity;
import com.fathur.moviecatalog.utils.DataDummy;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class TVShowViewModelTest {
    @Rule
    public InstantTaskExecutorRule instantTaskExecutorRule = new InstantTaskExecutorRule();
    private TVShowViewModel viewModel;
    @Mock
    private MovieRepository movieRepository;

    @Mock
    private Observer<List<TvShowEntity>> observer;

    @Before
    public void setUp() {
        viewModel = new TVShowViewModel(movieRepository);
    }

    @Test
    public void getTvShow() {
        ArrayList<TvShowEntity> dummytv = DataDummy.generateDummyTvShow();
        MutableLiveData<List<TvShowEntity>> tvshow = new MutableLiveData<>();
        tvshow.setValue(dummytv);

        when(movieRepository.getAllTVShow()).thenReturn(tvshow);
        List<TvShowEntity> tvShowEntities = viewModel.getTVShow().getValue();
        verify(movieRepository).getAllTVShow();
        assertNotNull(tvShowEntities);
        assertEquals(20, tvShowEntities.size());

        viewModel.getTVShow().observeForever(observer);
        verify(observer).onChanged(dummytv);
    }
}