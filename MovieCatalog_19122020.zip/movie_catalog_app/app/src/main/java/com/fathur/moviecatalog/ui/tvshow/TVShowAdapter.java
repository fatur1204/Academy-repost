package com.fathur.moviecatalog.ui.tvshow;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.fathur.moviecatalog.R;
import com.fathur.moviecatalog.data.source.local.entity.TvShowEntity;
import com.fathur.moviecatalog.databinding.ItemsTvshowBinding;
import com.fathur.moviecatalog.ui.detail.DetailMovieActivity;

import java.util.ArrayList;
import java.util.List;

public class TVShowAdapter extends RecyclerView.Adapter<TVShowAdapter.TVShowViewHolder> {
    private static final String TAG = TVShowAdapter.class.getSimpleName();
    private final TVShowFragmentCallback callback;
    private final List<TvShowEntity> listtvshow = new ArrayList<>();

    public TVShowAdapter(TVShowFragmentCallback callback) {
        this.callback = callback;
    }

    public void setTVShow(List<TvShowEntity> listtvshow) {
        if (listtvshow == null) return;
        this.listtvshow.clear();
        this.listtvshow.addAll(listtvshow);
    }

    @NonNull
    @Override
    public TVShowAdapter.TVShowViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemsTvshowBinding binding = ItemsTvshowBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
        return new TVShowViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull TVShowAdapter.TVShowViewHolder holder, int position) {
        TvShowEntity tvShowEntity = listtvshow.get(position);
        holder.bind(tvShowEntity);
    }

    @Override
    public int getItemCount() {
        return listtvshow.size();
    }

    public class TVShowViewHolder extends RecyclerView.ViewHolder {
        private ItemsTvshowBinding binding;

        public TVShowViewHolder(ItemsTvshowBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

        void bind(TvShowEntity tvShowEntity) {
            binding.tvItemTitle.setText(tvShowEntity.getTitle());
            binding.tvItemDate.setText(tvShowEntity.getWriteFilm());
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(itemView.getContext(), DetailMovieActivity.class);
                    intent.putExtra(DetailMovieActivity.EXTRA_VAL, "1");
                    intent.putExtra(DetailMovieActivity.EXTRA_MOVIES, tvShowEntity.getTvid());
                    itemView.getContext().startActivity(intent);
                }
            });
            binding.imgShare.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    callback.onShareClick(tvShowEntity);
                }
            });
            Glide.with(itemView.getContext())
                    .load(tvShowEntity.getImagePath())
                    .apply(RequestOptions.placeholderOf(R.drawable.ic_loading).error(R.drawable.ic_error))
                    .into(binding.imgPoster);
        }
    }
}
