package com.fathur.moviecatalog.vo;

public enum Status {
    SUCCESS,
    ERROR,
    LOADING
}
