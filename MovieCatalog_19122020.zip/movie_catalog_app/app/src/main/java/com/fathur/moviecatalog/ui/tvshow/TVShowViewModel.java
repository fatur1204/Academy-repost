package com.fathur.moviecatalog.ui.tvshow;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.ViewModel;

import com.fathur.moviecatalog.data.source.MovieRepository;
import com.fathur.moviecatalog.data.source.local.entity.TvShowEntity;
import com.fathur.moviecatalog.vo.Resource;

import java.util.List;

public class TVShowViewModel extends ViewModel {
    private MovieRepository tvShowRepository;

    public TVShowViewModel(MovieRepository mtvShowRepository) {
        this.tvShowRepository = mtvShowRepository;
    }

    public LiveData<Resource<List<TvShowEntity>>> getTVShow() {
        return tvShowRepository.getAllTVShow();
    }
}
