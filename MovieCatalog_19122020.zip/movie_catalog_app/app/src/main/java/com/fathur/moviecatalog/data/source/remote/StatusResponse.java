package com.fathur.moviecatalog.data.source.remote;

public enum StatusResponse {
    SUCCESS,
    EMPTY,
    ERROR
}
